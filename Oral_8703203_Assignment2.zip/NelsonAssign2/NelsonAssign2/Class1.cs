﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;

namespace Rectangular
{
    public class Program
    {
        public static void Main(string[] args)
        {

            bool exitIndicator = false;
            int length = 5, width = 10, perimeter = 0, area = 0;
            string menu = "";

            do
            {
                Console.WriteLine("1. Get Rectangle Length \n");
                Console.WriteLine("2. Change Rectangle Length \n");
                Console.WriteLine("3. Get Rectangle Width \n");
                Console.WriteLine("4. Change Rectangle Width \n");
                Console.WriteLine("5. Get Rectangle Perimeter \n");
                Console.WriteLine("6. Get Rectangle Area \n");
                Console.WriteLine("7. Exit \n");

                menu = Console.ReadLine();
                if (menu == "1" || menu == "2" || menu == "3" || menu == "4"
                    || menu == "5" || menu == "6" || menu == "7")
                {
                    Console.Clear();
                    switch (menu)
                    {
                        case "1":
                            length = Rectangle.GetRectangleLength(length);
                            Console.WriteLine("The current length is " + length);
                            Console.ReadLine();
                            break;
                        case "2":
                            length = Rectangle.ChangeRectangleLength(length);
                            Console.WriteLine("The length has been changed to " + length);
                            Console.ReadLine();
                            break;
                        case "3":
                            width = Rectangle.GetRectangleWidth(width);
                            Console.WriteLine("The current width is " + width);
                            Console.ReadLine();
                            break;
                        case "4":
                            width = Rectangle.ChangeRectangleWidth(width);
                            Console.WriteLine("The width has been changed to " + width);
                            Console.ReadLine();
                            break;
                        case "5":
                            perimeter = Rectangle.GetRectanglePerimeter(length, width);
                            Console.WriteLine("The Perimeter of the Rectangle is " + perimeter);
                            Console.ReadLine();
                            break;
                        case "6":
                            area = Rectangle.GetRectangleArea(length, width);
                            Console.WriteLine("The Perimeter of the Rectangle is " + area);
                            Console.ReadLine();
                            break;
                        case "7":
                            exitIndicator = true;
                            break;

                    }
                }
                else
                {
                    Console.WriteLine("Input Error:\n Please enter any one numeric value from 1 to 7\n");
                }

            } while (exitIndicator == false);
        }
    }
}
