﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;



namespace Rectangular
{
    public class Rectangle
    {
        public  static int GetRectangleLength(int input)

        {
            int length = input;
            return length;
        }

        public static int ChangeRectangleLength(int input)
        {
            int length = input;
            Console.WriteLine("Pleae Enter Length:");
            length = Convert.ToInt32(Console.ReadLine());
            return length;
        }

        public static int GetRectangleWidth(int input)
        {
            int width = input;
            return width;
        }

        public static int ChangeRectangleWidth(int input)
        {
            int width = input;
            Console.WriteLine("Pleae Enter Width:");
            width = Convert.ToInt32(Console.ReadLine());
            return width;
        }

        public static int GetRectanglePerimeter(int num1, int num2)
        {
            int length = num1;
            int width = num2;
            int perimeter = 2 * (length + width);

            return perimeter;
        }

        public static int GetRectangleArea(int num1, int num2)
        {
            int length = num1;
            int width = num2;
            int area = length * width;

            return area;
        }
    }
}
