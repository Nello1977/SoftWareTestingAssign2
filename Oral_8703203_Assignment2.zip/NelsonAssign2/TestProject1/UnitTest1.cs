
using Microsoft.VisualStudio.TestPlatform.CommunicationUtilities;
using NUnit.Framework.Constraints;

namespace TestProject1
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void Input_Length()
        {
            int expected = 5;

            int actual = Rectangular.Rectangle.GetRectangleLength(expected);
            Assert.AreEqual(expected, actual);
        }

        [Test]
        public void Input_width()
        {
            int width = 3;

            int actual = Rectangular.Rectangle.GetRectangleWidth(width);
            Assert.AreEqual(width, actual);
        }


        [TestCase(6, 8)]
        public void Validate_Area(int a, int b)
        {
            int value = 2 * (a + b);
            int actual = Rectangular.Rectangle.GetRectanglePerimeter(a, b);
            Assert.AreEqual(value, actual);
        }

        [TestCase(6, 8)]
        public void Validate_Perimeter(int a, int b)
        {
            int value = a * b;
            int actual = Rectangular.Rectangle.GetRectangleArea(a, b);
            Assert.AreEqual(value, actual);
        }



        [Test]
        public void Calculate_Perimeter_Update_Results()
        {
            int width = 3;
            int length = 5;
            int perimeter = 2 * (width + length);

            int result = Rectangular.Rectangle.GetRectanglePerimeter(width, length);
            Assert.AreEqual(perimeter, result);
        }

        [Test]
        public void Calculate_Area_Update_Results()
        {
            int width = 3;
            int length = 5;
            int Area = (width * length);

            int result = Rectangular.Rectangle.GetRectangleArea(width, length);
            Assert.AreEqual(Area, result);
        }

        [Test]
        public async Task Calculate_Area_validate_Results()
        { }

        [Test(ExpectedResult = 4)]
        public int TeGetRectangleArea()
        {
            return 2 * 2;
        }

        [Test]
        public async Task validate_Perimeter()
        { }

        [Test(ExpectedResult = 8)]
        public int TeGetRectanglePerimeter()
        {
            return 2*(2 + 2);
        }

        [Test]
        public async Task Enter_Value_Return_Length()
        { }

        [Test(ExpectedResult = 2)]
        public int ChangeRectangleLength()
        {
            int a = 2;
            Console.WriteLine("Your Length is " + a);
            return 2;
        }
        [Test]
        public async Task Enter_Value_Return_Width()
        { }

        [Test(ExpectedResult = 4)]
        public int TChangeRectangleWidth()
        {
            int a = 4;
            Console.WriteLine("Your Width is " + a);
            return 4;
        }

        [TestCase(4)]
        
        public void Input_Integer_Value_Length_Field(int expected, params int[] numbers)
        {
            
            int NewValue = Rectangular.Rectangle.GetRectangleLength(expected);
            Assert.AreEqual(expected, NewValue);
        }

        [TestCase(6)]

        public void Input_Integer_Value_Width_Field(int expected, params int[] numbers)
        {

            int NewValue = Rectangular.Rectangle.GetRectangleWidth(expected);
            Assert.AreEqual(expected, NewValue);
        }

        [Test]
        public void Input_Required_Update_length()
        {
            
        }

        private void Length(int input, int expected)
        {
            int num = Rectangular.Rectangle.GetRectangleLength(expected);
            Assert.AreEqual(expected, input);
        }

        [Test]
        public void Input_Required_Update_Width()
        {

        }

        private void Width(int input, int expected)
        {
            int num = Rectangular.Rectangle.GetRectangleWidth(expected);
            Assert.AreEqual(expected, input);
        }
    }


}

